<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="//cdn.datatables.net/1.10.9/js/jquery.dataTables.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.2.4/js/dataTables.buttons.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.2.4/js/buttons.flash.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/select/1.2.0/js/dataTables.select.min.js"></script>
<script src="https://code.jquery.com/ui/1.11.3/jquery-ui.min.js"></script>
<script src="{{ url('adminlte/js') }}/bootstrap.min.js"></script>
<script src="{{ url('adminlte/js') }}/select2.full.min.js"></script>
<script src="{{ url('adminlte/js') }}/main.js"></script>

<script src="{{ url('adminlte/plugins/slimScroll/jquery.slimscroll.min.js') }}"></script>
<script src="{{ url('adminlte/plugins/fastclick/fastclick.js') }}"></script>
<script src="{{ url('adminlte/js/app.min.js') }}"></script>
<script>
    window._token = '{{ csrf_token() }}';
</script>

<script type="text/javascript">
	$(function(){
		$(".datepicker").datepicker({
		  dateFormat: 'yy-mm-dd',
		  autoclose: true,
		  todayHighlight: true,
		});
	});
</script>

<script type="text/javascript">
  	$(document).ready(function() {
    	$('.table').dataTable({
	      "paging": true,
	      "lengthChange": true,
	      "searching": true,
	      "ordering": true,
	      "info": true,
	      "autoWidth": true,
	      "bDestroy": true,
	      "columnDefs": [{
  		    	"defaultContent": "-",
  		    	"targets": "_all"
  		  }]
	    });
	});
</script>

<script type="text/javascript">
  	$(document).ready(function() {
    	$('.dynamic').change(function(){
    		if($(this).val() != ''){
    			var select = $(this).attr("id");
    			var value = $(this).val();
    			var dependent = $(this).data('dependent');
    			var _token = $('input[name="_token"]').val();
    			$.ajax({
    				url:"{{ route('dev.applicationscontroller.fetch') }}",
    				method:"POST",
    				data:{select:select, value:value, _token:_token, dependent:dependent},
    				success:function(result)
    				{
    					$('#'+dependent).html(result);
    				}
    			})
    		}
    	});
	});
</script>

<script type="text/javascript">  
 $(document).ready(function(){  
      $('.view_data').click(function(){  
           var employee_id = $(this).attr("id");  
           var _token = $('input[name="_token"]').val();
           $.ajax({  
                url:"{{ route('dev.applicationscontroller.serverprod') }}",
                method:"post",  
                data:{employee_id:employee_id, _token:_token},  
                success:function(data){  
                     $('#serverDetail').html(data);  
                     $('#dataModal').modal("show");  
                }  
           });  
      });  
 });  
</script>

@yield('javascript')