@extends('layouts.app')

@section('content')
    <h3 class="page-title">@lang('global.permissions.title')</h3>
    
    {!! Form::model($sec_license, ['method' => 'PUT', 'route' => ['sec.license.update', $sec_license->id]]) !!}

    <div class="panel panel-default">
        <div class="panel-heading">
            @lang('global.app_edit')
        </div>

        <div class="panel-body">
            <div class="row">
                <div class="col-xs-6 form-group">
                    {!! Form::label('name', 'License Name*', ['class' => 'control-label']) !!}
                    {!! Form::text('license_name', old('license_name'), ['class' => 'form-control', 'placeholder' => '', 'required' => '', 'name' => 'license_name']) !!}
                </div>
                <div class="col-xs-6 form-group">
                    {!! Form::label('name', 'Expired Date*', ['class' => 'control-label']) !!}
                    {!! Form::text('license_expired_date', old('license_expired_date'), ['class' => 'form-control datepicker', 'placeholder' => '', 'required' => '', 'name' => 'license_expired_date']) !!}
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    {!! Form::label('name', 'License information*', ['class' => 'control-label']) !!}
                    {!! Form::textarea('license_information', old('license_information'), ['class' => 'form-control', 'placeholder' => '', 'required' => '', 'name' => 'license_information']) !!}
                </div>
            </div>
        </div>
    </div>

    {!! Form::submit(trans('global.app_update'), ['class' => 'btn btn-danger']) !!}
    {!! Form::close() !!}
@stop

