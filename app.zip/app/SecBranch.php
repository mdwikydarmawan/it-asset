<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SecBranch extends Model
{

    protected $table = 'sec_branch'; 

    protected $fillable = [

        'id',
        'branch_name',
        'branch_code',
        'branch_address',
        'branch_telephone',
        'branch_ip_telkom',
        'branch_ip_lintas',
        'branch_indihome_id',
        'created_at',
        'updated_at',

    ];

}